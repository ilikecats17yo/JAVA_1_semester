/* Project Secure TicTacToe 
 * Artur Barcij s216217
 * 22/01/23
 */

 import java.net.ServerSocket;
 import java.net.Socket;
 import java.util.Scanner;
 import java.io.*;



public class SecureTicTacToe{
    
    

    SecureTicTacToe(){
        
        


    }
    public static void main(String[] args) {
        final int port = 1062;
        System.out.println("Opretter forbindelse");
        ServerSocket serversock = null;
        Socket s = null;
        String URL = "ftnk-ctek01.win.dtu.dk";
        

        try {
            s = new Socket(URL, port);
        } catch (Exception e) {
            System.out.println("Kunne ikke åbne forbindelse");
        }
        System.out.println("Klient siden er forbundet med adresse " + URL + " med port " + port);
    

        try {serversock = new ServerSocket(port);}
        catch(IOException ex) {System.out.println("Socket Fejl");}
        System.out.println("Server siden med port " + port + " er forbundet.");
        
        boolean serverAktiv = true;

        while(serverAktiv){
                
            Socket sock = null;
            try{sock = serversock.accept();}
            catch(IOException ex) {System.out.println("Accept Fejl");}

            BufferedInputStream bfi = null;
            try{bfi = new BufferedInputStream(sock.getInputStream());}
            catch(IOException ex) {System.out.println("Input Fejl");}

            BufferedOutputStream bfo = null;
            try {
                bfo = new BufferedOutputStream(sock.getOutputStream());
            } catch (IOException ex) {
                System.out.println("Output Fejl");
            }
            
            

            try{sock.close();}
            catch(IOException ex) {System.out.print("Kunne ikke lukke socket");}
            
        }

        try {serversock.close();}
		catch(IOException ex) {System.out.print("Kunne ikke lukke server");}
       


        
    }

}