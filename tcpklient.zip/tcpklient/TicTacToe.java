//Artur
//Lukas
//Alperen

import java.net.Socket;
import java.io.*;
import java.util.*;

public class TicTacToe {

	public static String P1 (String netin) {
		for(int j = 0; j < 3; j++) {
			System.out.print("| "+(netin.charAt(j))+" ");
		}
		System.out.println("|");
		return " ";
	}
	public static String P2 (String netin) {
		for(int j = 3; j < 6; j++) {
			System.out.print("| "+(netin.charAt(j))+" ");
		}
		System.out.println("|");
		return " ";
	}
	public static String P3 (String netin) {
		for(int j = 6; j < 9; j++) {
			System.out.print("| "+(netin.charAt(j))+" ");
		}
		System.out.println("|");
		return " ";
	}
	
	public static void main(String[] args) {
		System.out.println("Opretter forbindelse");
		Socket sock = null;
		try {sock = new Socket("ftnk-ctek01.win.dtu.dk", 1060);}
		catch(IOException ex) {System.out.println("Kunne ikke åbne forbindelse");}
		
		Scanner netin = null;
		try {netin = new Scanner(sock.getInputStream());}
		catch(IOException ex) {System.out.println("Kunne ikke oprette Scanner");}
		
		PrintWriter pw = null;
		try {pw = new PrintWriter(sock.getOutputStream());}
		catch(IOException ex) {System.out.println("Kunne ikke oprette PrintWriter");}
		
		boolean aktiv = true;
		System.out.println(netin.nextLine());
		
		while(aktiv) {
			System.out.println(netin);
			System.out.println(netin);
			
			Scanner brugerChoice = new Scanner(System.in);
			String BrugerChoice = brugerChoice.nextLine();

				pw.println(BrugerChoice);
			
    		pw.flush();

			for(int i = 0; i <= 1; i++){
				String Netin = netin.nextLine();
				System.out.println(Netin);
				if(Netin.equals("ILLEGAL INPUT") || Netin.equals("ILLEGAL MOVE")){}
				else if(i == 0) {
					boardGame(Netin);
					}
			}

		}
			try {
				netin.close();
				pw.close();
				sock.close();
				System.exit(0);
			} catch (IOException ex) {
				System.out.println("Forbindelse kan ikke afbrydes");
			}
			//Check om dette var sidste gang
			//Tegn board
			//Modtag input fra bruger
			//Send input via PW og flush
		
	}
	public static void boardSetup() {
		for (int a = 1; a <= 3; a++) {
			System.out.println("+---+");
			System.out.println("|1  |");
			System.out.println("|2   |");
			System.out.println("|3   |");
		}
		System.out.println();
		
		for (int b = 1; b <= 3; b++) {
			System.out.println("+---+");
			System.out.println("|4  |");
			System.out.println("|5   |");
			System.out.println("|6   |");
			System.out.println();
		}
		System.out.println();
		
		for (int c = 1; c <= 3; c++) {
			System.out.println("+---+");
			System.out.println("|7  |");
			System.out.println("|8   |");
			System.out.println("|9   |");
			System.out.println();
		}
		System.out.println();
		
			//3 for loops med variablen som felt tallet. 
	}

	public static void boardGame(String netin){
		System.out.println("+--------------+");
		System.out.println("|1  |2   |3   |");
		System.out.println("|   |    |    |");
		P1(netin);
		System.out.println("|4  |5   |6   |");
		System.out.println("|   |    |    |");
		P2(netin);
		System.out.println("|   |    |    |");
		System.out.println("|7  |8   |9   |");
		P3(netin);
		System.out.println("|   |    |    |");
		System.out.println("+--------------+");
	}
}
