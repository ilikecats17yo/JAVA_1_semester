import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.io.*;

public class webserver {
	
	public static void main(String[] args) {
		ServerSocket serversock = null;
		
		try {serversock = new ServerSocket(8080);}
		catch(IOException ex) {System.out.println("Socket Fejl");}
		
		BufferedInputStream bis;
		BufferedOutputStream bos;
		
		boolean serverAktiv = true;
		
		while(serverAktiv) {
			
			Socket sock = null;
			try {sock = serversock.accept();}
			catch(IOException ex) {System.out.println("Accept Fejl");}
			
			Scanner netin = null;
			try {netin = new Scanner(sock.getInputStream());}
			catch(IOException ex) {System.out.println("Scanner Fejl");}
			
			PrintWriter pw = null;
			try {pw = new PrintWriter(sock.getOutputStream());}
			catch(IOException ex) {System.out.println("PrintWriter Fejl");}
			
			String textline = netin.nextLine();
			
			System.out.println(textline);
			
			
			
			/*try {bis = new BufferedInputStream(sock.getInputStream());}
			catch(IOException ex) {System.out.println("bis Fejl");}
			
			try {bos = new BufferedOutputStream(sock.getOutputStream());}
			catch(IOException ex) {System.out.println("bos Fejl");}
			
			int x = bis.read();
			
			bos.write();
			bos.flush();*/
			
		
			try {sock.close();}
			catch(IOException ex) {System.out.print("Kunne ikke lukke socket");}
		}
	
		try {serversock.close();}
		catch(IOException ex) {System.out.print("Kunne ikke lukke server");}
	}
}