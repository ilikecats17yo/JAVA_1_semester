import java.util.ArrayList;
import java.io.IOException;
import java.util.Scanner;
import java.io.*;

public class Cat{
    private final String race;
    private final String color;
    private final int birthYear;
    String name;
    String owner;
    private final String gender;
    int countKittens;
    private int id;
    private static int nextId = 0;

    public Cat(String race, String color, int birthYear, String name, String owner, String gender, int countKittens){
        this.race = race;
        this.color = color;
        this.birthYear = birthYear;
        this.name = name;
        this.owner = owner;
        this.gender = gender;
        this.countKittens = countKittens;
        id = nextId++;

        if(this.gender.equals("male")){
            this.countKittens = 0;
        }
    }

    public String toString(){
        return "Cat(" + id + "): " + race + " " + color + " " + birthYear + " " + name + " " + owner + " " + gender + " " + countKittens;
    }

    public int numKittens(int countKittens){
        if ((this.countKittens < 0)){
            System.out.println("WRONG NUMBER OF KITTENS");
            
                Scanner scanner = new Scanner(System.in);
                System.out.println("Please input new number");
                int input = scanner.nextInt();
                while(input < 0){
                    System.out.println("Please input correct number of kittens");
                    scanner.nextInt();
                }
                return input;
                
        }
        return countKittens;
    }

    public void CatRegister(Cat cat){
        ArrayList<Cat> arr = new ArrayList<Cat>();
        arr.add(cat);
        System.out.println(arr);

        if(nextId > 9){
            System.out.println("LIST IS FULL");
        }

    }

    public static void main(String [] args){
        Cat c1 = new Cat("european", "black", 1999, "Penny", "Artur", "female", 5);
        Cat c2 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c3 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c4 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c5 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c6 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c7 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c8 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c9 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);
        Cat c10 = new Cat("shorthair", "striped", 1998, "Anton", "Artur", "male", 5);

        System.out.println(c1);
        System.out.println(c2.toString());
        System.out.println(c3.toString());
        
        c1.CatRegister(c1);
        c2.CatRegister(c2);
        c3.CatRegister(c3);
        c4.CatRegister(c4);
        /*
        for(int i = 0; i < Cat.ArrayList.length(); i++){
            //c[i].CatRegister(c[i]);
            System.out.println(c[i].toString());
        }
        */
    }
}