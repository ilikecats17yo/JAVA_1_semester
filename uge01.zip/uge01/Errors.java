package uge01;

public class Errors {

	public static void main(String[] args) {
        System.out.printlm("Java Java");
		System.out.println("Bali Bali")
	}
}
