package uge01;

public class QueenAndKing {
	
	static String regent = "king";

	public static void main(String[] args) {
		runProgram();
	}

	 static void runProgram() {
		System.out.println("The country has queen or a king.");
		System.out.println("Right now it is a "+regent+".");
		System.out.println("At new Years Eve the "+regent+" gives a speach.");
		System.out.println("In the summer the "+regent+" tours the land.");		
	}

}
