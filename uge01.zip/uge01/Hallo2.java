package uge01;

public class Hallo2 {

	public static void main(String[] args) {
		System.out.println("Godt, ikke");
		System.out.println("www");
	}

}
