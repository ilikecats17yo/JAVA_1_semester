package uge01;

public class HelloFormat {
	public static void main(String[] args) {
		System.out.

				println

				("Hello 02101")

		;

	}

}
