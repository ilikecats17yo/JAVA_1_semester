package uge01;

public class TreSmaaFisk {
	public static void main(String[] args) {
		   System.out.println("De tre sm� fisk, de sv�mmede rundt,");
		   System.out.println("for deres mor havde sagt, at sv�mning er sundt.");
		   System.out.println("Vikkedi-vukkedi-vikkedi-vukkedi vum-vum-vej.");
		   System.out.println("Vikkedi-vukkedi-vikkedi-vukkedi vum-vum-vej.");
		   System.out.println("De tre sm� fisk, de sv�mmede rundt,");
		   System.out.println("for deres mor havde sagt, at sv�mning er sundt.");
		 }
}
