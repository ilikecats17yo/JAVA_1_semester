package uge01;

public class Dummy {
	public static void main(String[] args) {
		System.out.println("Hallo 02101");
	}
}
