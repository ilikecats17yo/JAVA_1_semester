package uge01;

public class TreFisk_struct {

	public static void main(String[] args) {
		
		printChorusPart1();
		printChorusPart2a();
		printChorusPart1();
	}


	// alternatively:
	public static void printChorusPart2a() {
		System.out.println("Vikkedi-vukkedi-vikkedi-vukkedi vum-vum-vej.");


	}
	public static void printChorusPart2() {
		System.out.println("Vikkedi-vukkedi-vikkedi-vukkedi vum-vum-vej.");
		System.out.println("Vikkedi-vukkedi-vikkedi-vukkedi vum-vum-vej-vej.");

	}

	public static void printChorusPart1() {
		System.out.println("De tre sm� fisk, de sv�mmede rundt,");
		System.out.println("for deres mor havde sagt, at sv�mning er sundt.");

	}


}
