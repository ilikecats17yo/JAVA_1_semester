package uge01;

//class name
public class Hello {

	// "main" is called from the runtime environment
	// to start the program
	public static void main(String[] args) {
		
		// this is what actually is executed
		
		System.out.println("Hej verden!");
	
	}
}
