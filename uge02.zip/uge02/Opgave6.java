public class Opgave6{
    public static void main(String [] args){
        BuildFigure();
    }

    public static void BuildFigure() {
        for(int i = 0; i < 4; i++){
        Stars();
        }
    }

    public static void Stars() {
        System.out.println(" O  *******");
        System.out.println("/|\\ *     *");
        System.out.println("/ \\ *     *");
    }
}