package uge02;

public class Overflow {

	public static void main(String[] args) {
		int i1 = 2145992020;
		int i2 = 2145847472;
		int sum = i1 + i2;
		System.out.println("The sum of "+i1+" and "+i2+" is "+sum+".");
	}
}
